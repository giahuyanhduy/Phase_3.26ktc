const bcd = require("bcd");
const fs = require("fs");
const gracefulFs = require('graceful-fs');
gracefulFs.gracefulify(fs)
const winston = require('winston');
require('winston-daily-rotate-file');
const LOG_FOLDER = "./logs";
const MABOM_CURRENT_PATH = './mabomcurrent.json';
if (!fs.existsSync(LOG_FOLDER)) {
    fs.mkdir(LOG_FOLDER, () => {
    })
}
if (fs.existsSync(MABOM_CURRENT_PATH)) {
    fs.writeFile(MABOM_CURRENT_PATH, JSON.stringify({}), 'utf8', (err) => {
        console.log(err)
    });
}

const transport = new (winston.transports.DailyRotateFile)({
    filename: `${LOG_FOLDER}/application-%DATE%.log`,
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: '20m',
    maxFiles: '14d'
});

transport.on('rotate', function (oldFilename, newFilename) {
    // do something fun
});

const logger = winston.createLogger({
    transports: [
        transport
    ]
});

function writeLog() {
    console.log(Object.values(arguments))
}

function formatMoney(amount, decimalCount = 0, decimal = ".", thousands = ",") {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

    const negativeSign = amount < 0 ? "-" : "";

    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    let j = (i.length > 3) ? i.length % 3 : 0;

    return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
}

function numberToBCD(number) {
    return bcd.encode(number, 1)[0]
}

function saveMaBomCurrent(idcot, mabom) {
    fs.readFile(MABOM_CURRENT_PATH, 'utf8', function (err, data) {
        if (err) {
            console.log(err);
        } else {
            let obj = JSON.parse(data);
            obj[idcot] = mabom;
            fs.writeFile(MABOM_CURRENT_PATH, JSON.stringify(obj), 'utf8', () => {
            });
        }
    });
};

function getCurrentMaBom(idcot) {
    let data = fs.readFileSync(MABOM_CURRENT_PATH);
    let obj = JSON.stringify(data.toString());
    return obj[idcot];
}

module.exports = {formatMoney, numberToBCD, writeLog, saveMaBomCurrent, getCurrentMaBom};