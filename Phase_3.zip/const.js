let CMD = {
    STX: 0x10,
    cmdWR: charToByte('W'),// WRITE Bộ nhớ trong 		- OK
    cmdWTC: charToByte('t'),// WRITE Real Time Clock		- OK
    cmdCHP: charToByte('g'),// Thay đổi giá nguyên liệu	- OK
    cmdACT: charToByte('a'),// Active service			- OK
    cmdPMP: charToByte('u'),// lệnh bơm cài (lít,tiền)		- OK
    cmdRD: charToByte('R'),// READ Bộ nhớ trong.		- OK
    cmdRTC: charToByte('r'),// Read  Real Time Clock.		- OK
    cmdRDP: charToByte('m'),// Read Mã bơm.			- OK
    cmdRDS: charToByte('h'),// Read Mã ca.			- OK
    cmdPRO: charToByte('p'),// Read Product ID		- OK
    cmdFUP: charToByte('F'),// Lệnh Online trạng thái FULL.	- OK
    cmdQUP: charToByte('Q'),// Lệnh Online trạng thái Quick.	- OK
    cmdWEN: charToByte('x'),// Đặt cờ “WR_ENABLE=1”.	- OK
    cmdSTP: charToByte('Z'),// Lệnh dừng khẩn cấp E-STOP	- OK
    cmdRST: charToByte('o'),// Backup các dữ liệu và khởi động lại hệ thống.	- OK
    cmdCLS: charToByte('L'),// Chốt ca bán hàng.				- OK
    cmdBAK: charToByte('K'),// Backup data & clear WRITE_ENABLE flag	- OK
    cmdRDY: charToByte('d'),// Sẵn sàng nhận dữ liệu
    cmdACK: charToByte('A'),
    cmdNAK: charToByte('N'),
    cmdSTA: charToByte('?'), //Status cột bơm
    cmdINF: 0x49,
    cmdPUM: 0x55, 
    cmdLOF: 0x71
};
const ADDR = {
    Firmware_version: {bytecode: 0, nbyte: 2},
    Data_version: {bytecode: 1, nbyte: 1},
    Station_ID: {bytecode: 2, nbyte: 1},
    Serial_Number: {bytecode: 3, nbyte: 2},
    Xung_Per_Lit: {bytecode: 4, nbyte: 2},
    Unit_price: {bytecode: 5, nbyte: 4},
    Preset_LIT: {bytecode: 6, nbyte: 1},
    Preset_TIEN: {bytecode: 7, nbyte: 1},
    Rounding_Money: {bytecode: 8, nbyte: 2},
    Petro: {bytecode: 9, nbyte: 1},
    User_Password: {bytecode: 10, nbyte: 0},
    Owner_Password: {bytecode: 11, nbyte: 1},
    Login_Mode: {bytecode: 12, nbyte: 2},
    Pump_Code: {bytecode: 13, nbyte: 3},
    Curent_Lit: {bytecode: 14, nbyte: 4},
    Curent_Tien: {bytecode: 15, nbyte: 5},
    Shift_Total_Lit: {bytecode: 16, nbyte: 6},
    Shift_Total_mLit: {bytecode: 17, nbyte: 7},
    Grand_Total: {bytecode: 18, nbyte: 8},
    TotalCare: {bytecode: 19, nbyte: 2},
    TotalMoney: {bytecode: 20, nbyte: 4},
    Shift_code: {bytecode: 21, nbyte: 2}
};
const StatusBom = {
    0x10: "sẵn sàng",
    0x20: "nhắc cò",
    0x22: "đang bơm",
    0x23: "hãm",
    0x30: "gác cò",
    0x31: "tạm dừng",
    0x32: "menu",
    0x33: "Lock k bơm",
    0x40: "log off",
    0x80: "lỗi",
    0x50: "Xác thực",
	0x82: "Vòi bơm mất kết nối",
	0x83: "Invalid data"

};

function charToByte(char) {
    return Buffer.from(char, 'ascii')[0];
}

module.exports = {
    CMD, ADDR, StatusBom
}