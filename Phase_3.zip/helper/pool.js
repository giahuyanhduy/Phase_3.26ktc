const sql = require('mssql');
const {CONFIG_DATABASE} = require("../config");
let pool;

const utils = require("../utils")

module.exports = {
    init: (cb) => {
        // pool = new sql.ConnectionPool(CONFIG_DATABASE).connect(err => {
            // if (err) {
                // utils.writeLog(err);
                // throw err;
            // }
            utils.writeLog("OK ket noi db");
            cb(true);
        //});
    },
    getPool: () => {
        return pool;
    }
};